package sda;

//Node class for stack entries
class StackNode {
 String data;
 StackNode next;

 StackNode(String data) {
     this.data = data;
     this.next = null;
 }
}

//Custom Stack (LIFO) implementation
class CustomStack {
 private StackNode top;

 public boolean isEmpty() {
     return top == null;
 }

 public void push(String data) {
     StackNode newNode = new StackNode(data);
     newNode.next = top;
     top = newNode;
 }

 public String pop() {
     if (isEmpty()) return null;
     String value = top.data;
     top = top.next;
     return value;
 }

 public String peek() {
     return isEmpty() ? null : top.data;
 }
}

//Undo/Redo Manager for schedule edits
public class stacks {
 private CustomStack undoStack = new CustomStack();
 private CustomStack redoStack = new CustomStack();
 private String currentState = "";

 // Apply a new edit
 public void applyEdit(String newEdit) {
     undoStack.push(currentState);   // save current state for undo
     currentState = newEdit;
     redoStack = new CustomStack();  // clear redo history after new edit
 }

 // Undo operation
 public void undo() {
     if (!undoStack.isEmpty()) {
         redoStack.push(currentState);   // save current state for redo
         currentState = undoStack.pop(); // restore previous state
     } else {
         System.out.println("Nothing to undo.");
     }
 }

 // Redo operation
 public void redo() {
     if (!redoStack.isEmpty()) {
         undoStack.push(currentState);   // save current state for undo
         currentState = redoStack.pop(); // restore redo state
     } else {
         System.out.println("Nothing to redo.");
     }
 }

 // Show current schedule state
 public void showState() {
     System.out.println("Current Schedule: " + currentState);
 }
}
