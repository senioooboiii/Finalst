// Node class for BST
package sda;

class CandidateNode {
    int cid; // candidate index
    CandidateNode left, right;

    CandidateNode(int cid) {
        this.cid = cid;
        left = right = null;
    }
}

// BST class
public class CandidateBST {
    private CandidateNode root;

    // Insert a new candidate by cid
    public void insert(int cid) {
        root = insertRec(root, cid);
    }

    private CandidateNode insertRec(CandidateNode node, int cid) {
        if (node == null) {
            return new CandidateNode(cid);
        }
        if (cid < node.cid) {
            node.left = insertRec(node.left, cid);
        } else if (cid > node.cid) {
            node.right = insertRec(node.right, cid);
        }
        return node; // duplicates ignored
    }

    // Find a candidate by cid
    public boolean find(int cid) {
        return findRec(root, cid);
    }

    private boolean findRec(CandidateNode node, int cid) {
        if (node == null) return false;
        if (cid == node.cid) return true;
        if (cid < node.cid) return findRec(node.left, cid);
        return findRec(node.right, cid);
    }

    // Delete a candidate by cid
    public void delete(int cid) {
        root = deleteRec(root, cid);
    }

    private CandidateNode deleteRec(CandidateNode node, int cid) {
        if (node == null) return null;

        if (cid < node.cid) {
            node.left = deleteRec(node.left, cid);
        } else if (cid > node.cid) {
            node.right = deleteRec(node.right, cid);
        } else {
            // Case 1: Leaf node
            if (node.left == null && node.right == null) {
                return null;
            }
            // Case 2: One child
            else if (node.left == null) {
                return node.right;
            } else if (node.right == null) {
                return node.left;
            }
            // Case 3: Two children
            else {
                int minValue = minValue(node.right);
                node.cid = minValue;
                node.right = deleteRec(node.right, minValue);
            }
        }
        return node;
    }

    private int minValue(CandidateNode node) {
        int min = node.cid;
        while (node.left != null) {
            min = node.left.cid;
            node = node.left;
        }
        return min;
    }

    // Traversals
    public void inorder() {
        inorderRec(root);
        System.out.println();
    }

    private void inorderRec(CandidateNode node) {
        if (node != null) {
            inorderRec(node.left);
            System.out.print(node.cid + " ");
            inorderRec(node.right);
        }
    }

    public void preorder() {
        preorderRec(root);
        System.out.println();
    }

    private void preorderRec(CandidateNode node) {
        if (node != null) {
            System.out.print(node.cid + " ");
            preorderRec(node.left);
            preorderRec(node.right);
        }
    }

    public void postorder() {
        postorderRec(root);
        System.out.println();
    }

    private void postorderRec(CandidateNode node) {
        if (node != null) {
            postorderRec(node.left);
            postorderRec(node.right);
            System.out.print(node.cid + " ");
        }
    }
}
