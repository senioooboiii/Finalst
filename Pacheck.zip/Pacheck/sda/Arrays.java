package sda;

public class Arrays {
    private String[] candidates;
    private String[] employers;
    private int candidateCount;
    private int employerCount;

    public Arrays(int candidateCapacity, int employerCapacity) {
        candidates = new String[candidateCapacity];
        employers = new String[employerCapacity];
        candidateCount = 0;
        employerCount = 0;
    }

    public void addCandidate(String name) {
        if (candidateCount >= candidates.length) {
            System.out.println("Candidate array overflow! Cannot insert: " + name);
            return;
        }
        candidates[candidateCount++] = name;
    }

    public void addEmployer(String name) {
        if (employerCount >= employers.length) {
            System.out.println("Employer array overflow! Cannot insert: " + name);
            return;
        }
        employers[employerCount++] = name;
    }

    public void sortCandidates() {
        for (int i = 0; i < candidateCount - 1; i++) {
            for (int j = 0; j < candidateCount - i - 1; j++) {
                if (candidates[j].compareTo(candidates[j + 1]) > 0) {
                    String temp = candidates[j];
                    candidates[j] = candidates[j + 1];
                    candidates[j + 1] = temp;
                }
            }
        }
    }

    public void sortEmployers() {
        for (int i = 0; i < employerCount - 1; i++) {
            for (int j = 0; j < employerCount - i - 1; j++) {
                if (employers[j].compareTo(employers[j + 1]) > 0) {
                    String temp = employers[j];
                    employers[j] = employers[j + 1];
                    employers[j + 1] = temp;
                }
            }
        }
    }

    public void showCandidates() {
        System.out.println("Candidates:");
        for (int i = 0; i < candidateCount; i++) {
            System.out.println(" - " + candidates[i]);
        }
    }

    public void showEmployers() {
        System.out.println("Employers:");
        for (int i = 0; i < employerCount; i++) {
            System.out.println(" - " + employers[i]);
        }
    }
}
