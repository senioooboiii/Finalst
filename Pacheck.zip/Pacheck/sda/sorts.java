package sda;

public class sorts {

    public static void main(String[] args) {
        String[] candidateNames = {"Senio", "Harvey", "CK", "Sean"};
        int[] candidateScores = {85, 92, 78, 90};
        String[] employerNames = {"Kurt", "Matthew", "Luis", "Threo"};

        System.out.println("Original Data:");
        printArray(candidateNames, "Names");
        printArray(candidateScores, "Scores");
        printArray(employerNames, "Employers");

        // Bubble Sort on names
        bubbleSort(candidateNames);
        printArray(candidateNames, "Bubble Sorted Names");

        // Insertion Sort on scores
        insertionSort(candidateScores);
        printArray(candidateScores, "Insertion Sorted Scores");

        // Selection Sort on employers
        selectionSort(employerNames);
        printArray(employerNames, "Selection Sorted Employers");
    }

    // Bubble Sort for String[]
    public static void bubbleSort(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Insertion Sort for int[]
    public static void insertionSort(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    // Selection Sort for String[]
    public static void selectionSort(String[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j].compareTo(arr[minIdx]) < 0) {
                    minIdx = j;
                }
            }
            String temp = arr[minIdx];
            arr[minIdx] = arr[i];
            arr[i] = temp;
        }
    }

    // Print String[] with label
    public static void printArray(String[] candidateNames, String string) {
        System.out.print(string + ": ");
        for (String s : candidateNames) {
            System.out.print(s + " ");
        }
        System.out.println();
    }

    // Print int[] with label
    public static void printArray(int[] arr, String label) {
        System.out.print(label + ": ");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
