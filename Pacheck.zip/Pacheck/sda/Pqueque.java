package sda;

//Node structure for candidate/employer
class PQNode {
 String name;
 int priority;     // candidate score or employer urgency
 long timestamp;   // tie-breaker: earlier insertion wins

 PQNode(String name, int priority, long timestamp) {
     this.name = name;
     this.priority = priority;
     this.timestamp = timestamp;
 }
}

public class Pqueque {
 private PQNode[] heap;
 private int size;
 private int capacity;

 public Pqueque(int capacity) {
     this.capacity = capacity;
     this.heap = new PQNode[capacity];
     this.size = 0;
 }

 // Push (insert into heap)
 public void push(String name, int priority) {
     if (size == capacity) {
         System.out.println("Priority Queue is full. Cannot add: " + name);
         return;
     }
     PQNode node = new PQNode(name, priority, System.currentTimeMillis());
     heap[size] = node;
     siftUp(size);
     size++;
     System.out.println(name + " pushed with priority " + priority);
 }

 // Pop (remove highest priority)
 public PQNode pop() {
     if (size == 0) {
         System.out.println("Priority Queue underflow. Nothing to pop.");
         return null;
     }
     PQNode root = heap[0];
     heap[0] = heap[size - 1];
     size--;
     siftDown(0);
     System.out.println(root.name + " popped with priority " + root.priority);
     return root;
 }

 // Peek (view highest priority)
 public PQNode peek() {
     if (size == 0) {
         System.out.println("Priority Queue is empty.");
         return null;
     }
     System.out.println("Peek: " + heap[0].name + " (priority " + heap[0].priority + ")");
     return heap[0];
 }

 // Display heap contents
 public void display() {
     if (size == 0) {
         System.out.println("Priority Queue is empty.");
         return;
     }
     System.out.println("Priority Queue contents:");
     for (int i = 0; i < size; i++) {
         System.out.println((i + 1) + ". " + heap[i].name +
                            " (priority " + heap[i].priority +
                            ", ts " + heap[i].timestamp + ")");
     }
 }

 // Heapify upwards
 private void siftUp(int index) {
     while (index > 0) {
         int parent = (index - 1) / 2;
         if (compare(heap[index], heap[parent]) > 0) {
             swap(index, parent);
             index = parent;
         } else {
             break;
         }
     }
 }

 // Heapify downwards
 private void siftDown(int index) {
     while (index < size) {
         int left = 2 * index + 1;
         int right = 2 * index + 2;
         int largest = index;

         if (left < size && compare(heap[left], heap[largest]) > 0) {
             largest = left;
         }
         if (right < size && compare(heap[right], heap[largest]) > 0) {
             largest = right;
         }
         if (largest != index) {
             swap(index, largest);
             index = largest;
         } else {
             break;
         }
     }
 }

 // Comparison with tie-break policy
 private int compare(PQNode a, PQNode b) {
     if (a.priority != b.priority) {
         return a.priority - b.priority; // higher priority wins
     } else {
         return (int)(b.timestamp - a.timestamp); 
         // earlier timestamp wins → smaller ts = higher priority
     }
 }

 private void swap(int i, int j) {
     PQNode temp = heap[i];
     heap[i] = heap[j];
     heap[j] = temp;
 }

}
