package sda;



public class queue {
    private String[] queue;
    private int front;
    private int rear;
    private int size;
    private int capacity;

    public queue(int capacity) {
        this.capacity = capacity;
        this.queue = new String[capacity];
        this.front = 0;
        this.rear = -1;
        this.size = 0;
    }

    // Enqueue operation
    public void enqueue(String name) {
        if (size == capacity) {
            System.out.println("Queue is full. Cannot add: " + name);
            return;
        }
        rear = (rear + 1) % capacity;
        queue[rear] = name;
        size++;
        System.out.println(name + " added to the interview queue.");
    }

    // Dequeue operation
    public void dequeue() {
        if (size == 0) {
            System.out.println("Queue underflow. No one to dequeue.");
            return;
        }
        String removed = queue[front];
        front = (front + 1) % capacity;
        size--;
        System.out.println(removed + " removed from the interview queue.");
    }

    // Display queue contents
    public void displayQueue() {
        if (size == 0) {
            System.out.println("Queue is empty.");
            return;
        }
        System.out.println("Interview Queue:");
        for (int i = 0; i < size; i++) {
            int index = (front + i) % capacity;
            System.out.println((i + 1) + ". " + queue[index]);
        }
    }

    // Peek at the front of the queue
    public void peek() {
        if (size == 0) {
            System.out.println("Queue is empty. No one to peek.");
            return;
        }
        System.out.println("Next in line: " + queue[front]);
    }

    // Check if queue is empty
    public boolean isEmpty() {
        return size == 0;
    }

    // Check if queue is full
    public boolean isFull() {
        return size == capacity;
    }
}
