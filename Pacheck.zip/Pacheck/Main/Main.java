package Main;

import java.util.Scanner;

// Core modules
import sda.Arrays;               // Candidate/Employer registry
import sda.Pqueque;              // Priority Queue manager
import List.DoublyLinkedList;    // Timeline manager
import List.SinglyLinkedList;    // Log manager
import sda.sorts;                // Sorting demo
import sda.stacks;              // Undo/Redo schedule manager
import sda.CandidateBST;         // NEW: Binary Search Tree for candidate indexing

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // === Module Initialization ===
        Arrays registry = new Arrays(10, 10);               // Candidate/Employer registry
        Pqueque priorityQueue = new Pqueque(10);            // Priority Queue
        DoublyLinkedList timeline = new DoublyLinkedList(); // Timeline manager
        SinglyLinkedList log = new SinglyLinkedList();      // Log manager
        stacks scheduleManager = new stacks();              // Undo/Redo manager
        CandidateBST bst = new CandidateBST();              //  BST for candidate indexing

        int choice = 0;

        // === Main Menu Loop ===
        while (choice != 22) {
            System.out.println("\n====== SYSTEM MENU ======");
            System.out.println("1. Add Candidate");
            System.out.println("2. Add Employer");
            System.out.println("3. Push to Priority Queue");
            System.out.println("4. Pop from Priority Queue");
            System.out.println("5. Peek Highest Priority");
            System.out.println("6. Display Priority Queue");
            System.out.println("7. Add Timeline Event");
            System.out.println("8. Traverse Timeline Forward");
            System.out.println("9. Traverse Timeline Backward");
            System.out.println("10. Add Log Entry (Singly Linked List)");
            System.out.println("11. Remove Log Entry");
            System.out.println("12. Traverse Log");
            System.out.println("13. Run Sorting Demo");
            System.out.println("14. Schedule Manager (Undo/Redo)");

            // BST Operations
            System.out.println("16. BST: Insert Candidate ID");
            System.out.println("17. BST: Find Candidate ID");
            System.out.println("18. BST: Delete Candidate ID");
            System.out.println("19. BST: In-order Traversal");
            System.out.println("20. BST: Pre-order Traversal");
            System.out.println("21. BST: Post-order Traversal");

            System.out.println("22. Exit");
            System.out.println("================================");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            // === Menu Actions ===
            switch (choice) {
                case 1:
                    System.out.print("Enter candidate name: ");
                    String candidateName = sc.nextLine();
                    registry.addCandidate(candidateName);
                    break;

                case 2:
                    System.out.print("Enter employer name: ");
                    String employerName = sc.nextLine();
                    registry.addEmployer(employerName);
                    break;

                case 3: // Priority Queue: Push
                    System.out.print("Enter name: ");
                    String pqName = sc.nextLine();
                    System.out.print("Enter priority (higher = more urgent): ");
                    int priority = sc.nextInt();
                    sc.nextLine();
                    priorityQueue.push(pqName, priority);
                    System.out.println("Note: Tie-break policy favors earlier entries when priorities match.");
                    break;

                case 4: // Priority Queue: Pop
                    priorityQueue.pop();
                    break;

                case 5: // Priority Queue: Peek
                    priorityQueue.peek();
                    System.out.println("Reminder: Earlier timestamp wins when priorities are equal.");
                    break;

                case 6: // Priority Queue: Display
                    priorityQueue.display();
                    break;

                case 7: // Timeline: Add Event
                    System.out.print("Enter timeline event: ");
                    String event = sc.nextLine();
                    timeline.insert(event);
                    System.out.println("Event added to timeline.");
                    break;

                case 8: // Timeline: Traverse Forward
                    System.out.println("Timeline (Forward):");
                    timeline.traverseForward();
                    break;

                case 9: // Timeline: Traverse Backward
                    System.out.println("Timeline (Backward):");
                    timeline.traverseBackward();
                    break;

                case 10: // Log: Add Entry
                    System.out.print("Enter log entry: ");
                    String logEntry = sc.nextLine();
                    log.insert(logEntry);
                    System.out.println("Log entry added.");
                    break;

                case 11: // Log: Remove Entry
                    System.out.print("Enter log entry to remove: ");
                    String removeEntry = sc.nextLine();
                    log.remove(removeEntry);
                    System.out.println("Log entry removed if it existed.");
                    break;

                case 12: // Log: Traverse
                    System.out.println("Log (Singly Linked List):");
                    log.traverse();
                    break;

                case 13: // Sorting Demo
                    System.out.println("Running sorting demo from sda.sorts...");
                    sorts.main(null); // invokes the demo
                    break;

                case 14: // Schedule Manager
                    System.out.println("Schedule Manager Options:");
                    System.out.println("a) Apply Edit");
                    System.out.println("b) Undo");
                    System.out.println("c) Redo");
                    System.out.println("d) Show Current State");
                    System.out.print("Choose option (a/b/c/d): ");
                    String subChoice = sc.nextLine();
                    switch (subChoice) {
                        case "a":
                            System.out.print("Enter new schedule edit: ");
                            String newEdit = sc.nextLine();
                            scheduleManager.applyEdit(newEdit);
                            System.out.println("Edit applied.");
                            break;
                        case "b":
                            scheduleManager.undo();
                            break;
                        case "c":
                            scheduleManager.redo();
                            break;
                        case "d":
                            scheduleManager.showState();
                            break;
                        default:
                            System.out.println("Invalid schedule option.");
                    }
                    break;

                // ✅ BST Operations
                case 16:
                    System.out.print("Enter Candidate ID to insert into BST: ");
                    int cidInsert = sc.nextInt();
                    bst.insert(cidInsert);
                    break;

                case 17:
                    System.out.print("Enter Candidate ID to find in BST: ");
                    int cidFind = sc.nextInt();
                    boolean found = bst.find(cidFind);
                    System.out.println(found ? "Candidate found in BST." : "Candidate not found.");
                    break;

                case 18:
                    System.out.print("Enter Candidate ID to delete from BST: ");
                    int cidDelete = sc.nextInt();
                    bst.delete(cidDelete);
                    break;

                case 19:
                    System.out.println("BST In-order Traversal:");
                    bst.inorder();
                    break;

                case 20:
                    System.out.println("BST Pre-order Traversal:");
                    bst.preorder();
                    break;

                case 21:
                    System.out.println("BST Post-order Traversal:");
                    bst.postorder();
                    break;

                case 22:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        sc.close();
    }
}
