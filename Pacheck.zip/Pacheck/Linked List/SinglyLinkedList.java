package List;



//Singly Linked List Node
class SLLNode {
String data;
SLLNode next;

SLLNode(String data) {
   this.data = data;
   this.next = null;
}
}

//Singly Linked List
public class SinglyLinkedList {
	 private SLLNode head;

	 // Insert at end
	 public void insert(String data) {
	     SLLNode newNode = new SLLNode(data);
	     if (head == null) {
	         head = newNode;
	         return;
	     }
	     SLLNode current = head;
	     while (current.next != null) {
	         current = current.next;
	     }
	     current.next = newNode;
	 }

	 // Remove by value
	 public void remove(String data) {
	     if (head == null) return;

	     if (head.data.equals(data)) {
	         head = head.next;
	         return;
	     }

	     SLLNode current = head;
	     while (current.next != null && !current.next.data.equals(data)) {
	         current = current.next;
	     }
	     if (current.next != null) {
	         current.next = current.next.next;
	     }
	 }

	 // Traverse
	 public void traverse() {
	     SLLNode current = head;
	     while (current != null) {
	         System.out.print(current.data + " -> ");
	         current = current.next;
	     }
	     System.out.println("null");
	 }
	}

	//Doubly Linked List Node
	class DLLNode {
	 String data;
	 DLLNode prev, next;

	 DLLNode(String data) {
	     this.data = data;
	     this.prev = null;
	     this.next = null;
	 }
	}