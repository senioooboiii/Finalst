package List;



public class DoublyLinkedList {
private DLLNode head;
private DLLNode tail;

// Insert at end
public void insert(String data) {
    DLLNode newNode = new DLLNode(data);
    if (head == null) {
        head = tail = newNode;
        return;
    }
    tail.next = newNode;
    newNode.prev = tail;
    tail = newNode;
}

// Remove by value
public void remove(String data) {
    DLLNode current = head;
    while (current != null && !current.data.equals(data)) {
        current = current.next;
    }
    if (current == null) return;

    if (current.prev != null) {
        current.prev.next = current.next;
    } else {
        head = current.next;
    }

    if (current.next != null) {
        current.next.prev = current.prev;
    } else {
        tail = current.prev;
    }
}

// Traverse forward
public void traverseForward() {
    DLLNode current = head;
    while (current != null) {
        System.out.print(current.data + " <-> ");
        current = current.next;
    }
    System.out.println("null");
}

// Traverse backward
public void traverseBackward() {
    DLLNode current = tail;
    while (current != null) {
        System.out.print(current.data + " <-> ");
        current = current.prev;
    }
    System.out.println("null");
}
}
